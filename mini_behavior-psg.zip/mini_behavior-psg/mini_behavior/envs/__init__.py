# from mini_behavior.envs.boxing_books_up_for_storage import *
# from mini_behavior.envs.cleaning_a_car import *
# from mini_behavior.envs.cleaning_shoes import *
# from mini_behavior.envs.cleaning_up_the_kitchen_only import *
# from mini_behavior.envs.collect_misplaced_items import *
# from mini_behavior.envs.installing_a_printer import *
# from mini_behavior.envs.laying_wood_floors import *
# from mini_behavior.envs.making_tea import *
# from mini_behavior.envs.moving_boxes_to_storage import *
# from mini_behavior.envs.opening_packages import *
# from mini_behavior.envs.organizing_file_cabinet import *
# from mini_behavior.envs.preparing_salad import *
# from mini_behavior.envs.putting_away_dishes_after_cleaning import *
# from mini_behavior.envs.setting_up_candles import *
# from mini_behavior.envs.sorting_books import *
# from mini_behavior.envs.storing_food import *
# from mini_behavior.envs.thawing_frozen_food import *
# from mini_behavior.envs.throwing_away_leftovers import *
# from mini_behavior.envs.transition import *
# from mini_behavior.envs.washing_pots_and_pans import *
# from mini_behavior.envs.watering_houseplants import *
#
# from mini_behavior.envs.navigation import *
# from mini_behavior.envs.throwleftovers_floorplan import *
# from mini_behavior.envs.two_room_nav import *
#
# # extra
# from mini_behavior.envs.bc_installing_a_printer import *
# from mini_behavior.envs.preparing_salad_floorplan import *

# PSG
from mini_behavior.envs.fixed_scene import *
